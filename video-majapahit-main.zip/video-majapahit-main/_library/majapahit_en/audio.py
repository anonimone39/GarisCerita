import numpy as np, soundfile as sf, json
from scipy import signal
SR = 44100
import json as _j, os as _os
WARP = _j.load(open('audio/warp.json')) if _os.path.exists('audio/warp.json') else None
def toNew(x):
    if not WARP: return x
    A = WARP['anchors']
    if x <= A[0][0]: return x - A[0][0] + A[0][1]
    for i in range(len(A) - 1):
        if x <= A[i + 1][0]: k = (x - A[i][0]) / (A[i + 1][0] - A[i][0]); return A[i][1] + k * (A[i + 1][1] - A[i][1])
    return x - A[-1][0] + A[-1][1]
DUR = (WARP['new_end'] + 0.6 if WARP else 37.4) + 0.6
N = int(DUR * SR)
rng = np.random.default_rng(3)
def T(n): return np.arange(n) / SR
def env(n, a=.005, d=.2, curve=4):
    t = T(n); e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-np.maximum(0, t - a) * curve / max(d, 1e-4)); return e
def place(buf, x, at, g=1.0):
    i = int(toNew(at) * SR); j = min(len(buf), i + len(x))
    if i < 0 or i >= len(buf): return
    buf[i:j] += x[:j - i] * g
def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi / (SR / 2), .99)], 'band'); return signal.lfilter(b, a, x)
def lp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)

# ---------------- SFX ----------------
def whoosh(dur=.35, up=True):
    n = int(dur * SR); x = rng.standard_normal(n); t = T(n)
    lo, hi = bp(x, 250, 1200), bp(x, 1500, 6000); k = np.linspace(0, 1, n) if up else np.linspace(1, 0, n)
    e = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.5
    return (lo * (1 - k) + hi * k) * e * 1.6
def thud(f0=70, dur=.35, g=1):
    n = int(dur * SR); t = T(n); f = f0 * (1 + 1.5 * np.exp(-t * 30))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 12)
    x += lp(rng.standard_normal(n), 900) * np.exp(-t * 40) * .6
    return x * g
def clang(f0=520, dur=1.0):
    n = int(dur * SR); t = T(n); x = np.zeros(n)
    for k, (r, a, d) in enumerate([(1, 1, 5), (2.76, .6, 7), (5.4, .4, 10), (8.9, .25, 14), (1.5, .5, 6)]):
        x += a * np.sin(2 * np.pi * f0 * r * t + k) * np.exp(-t * d)
    x += hp(rng.standard_normal(n), 2000) * np.exp(-t * 60) * .8
    return x * .5 + thud(90, dur, .7)[:n]
def pluck(f, dur=.5, bright=.5):
    n = int(dur * SR); p = int(SR / f); buf = rng.uniform(-1, 1, p); out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % p]; buf[i % p] = bright * buf[i % p] + (1 - bright) * .5 * (buf[i % p] + buf[(i + 1) % p]) * .996 if False else .5 * (buf[i % p] + buf[(i + 1) % p]) * .995
    return out
def chime(f=1760, dur=.8):
    n = int(dur * SR); t = T(n)
    return (np.sin(2 * np.pi * f * t) + .5 * np.sin(2 * np.pi * f * 2.01 * t) + .3 * np.sin(2 * np.pi * f * 3 * t)) * np.exp(-t * 6) * np.minimum(1, t / .003) * .5
def sparkle_sfx():
    out = np.zeros(int(.7 * SR))
    for i, f in enumerate([2093, 2637, 3136, 4186]): place(out, chime(f, .5) * .5, i * .05)
    return out
def tick(): n = int(.04 * SR); t = T(n); return hp(rng.standard_normal(n), 3000) * np.exp(-t * 200) * .8 + np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 150) * .4
def pop(f=600):
    n = int(.12 * SR); t = T(n); fr = f * (1 + 2 * t * 10); return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 40)
def boing(f=220, dur=.5):
    n = int(dur * SR); t = T(n); fr = f * (1 + .35 * np.sin(2 * np.pi * 9 * t) * np.exp(-t * 3)) * (1 + t)
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 5) * .6
def tweet():
    out = np.zeros(int(1.2 * SR))
    for i in range(4):
        n = int(.1 * SR); t = T(n); fr = 3200 + 900 * np.sin(2 * np.pi * 30 * t)
        place(out, np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.sin(np.pi * t / .1) * .25, i * .25)
    return out
def scribble(dur=.18):
    n = int(dur * SR); t = T(n); return bp(rng.standard_normal(n), 1500, 6000) * (0.5 + .5 * np.sin(2 * np.pi * 30 * t)) * np.sin(np.pi * t / dur) * .5
def riser(dur=2.8):
    n = int(dur * SR); t = T(n); f = 200 * (2 ** (t / dur * 2.5))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * .3 + bp(rng.standard_normal(n), 800, 5000) * .3 * (t / dur)
    return x * (t / dur) ** 2
def waves(dur):
    n = int(dur * SR); t = T(n); x = lp(rng.standard_normal(n), 700, 2)
    return x * (0.5 + .5 * np.sin(2 * np.pi * t / 4.5) ** 2) * .5
def heartbeat():
    out = np.zeros(int(.8 * SR)); place(out, thud(55, .3, .8), 0); place(out, thud(50, .3, .6), .22); return out

sfx = np.zeros(N)
import re as _re
_src = open('web/shots.js').read()
_shots = [(float(s), float(e), tr) for s, e, tr in _re.findall(r"start: ([\d.]+), end: ([\d.]+), tr: '(\w+)'", _src)]
for s, e, tr in _shots[:-1]:
    if tr == 'whip': place(sfx, whoosh(.36), e - .22, .35)
def noiseburst(dur=.08, lo=1500, hi=7000):
    n = int(dur * SR); return bp(rng.standard_normal(n), lo, hi) * np.exp(-T(n) * 40)
def steps(t0, t1, every, f=140, g=.22):
    t = t0
    while t < t1: place(sfx, thud(f, .07, 1), t, g); t += every
def crackle(t0, t1, g=.12):
    t = t0
    while t < t1: place(sfx, noiseburst(.03, 2000, 8000), t, g * (.5 + rng.random())); t += .05 + rng.random() * .12
# 1 hook
place(sfx, thud(48, .8, 1), 0, .6); crackle(0, 3.3)
for i in range(4): place(sfx, pop(550 + i * 60), 1.2 + i * .12, .3)
for st in (3.67, 4.42, 5.17): place(sfx, thud(52, .45, 1), st, .85)
place(sfx, pop(500), 6.0, .4); place(sfx, scribble(.25), 6.15, .4); place(sfx, chime(2637, .5), 6.6, .35); place(sfx, tick(), 6.95, .5)
place(sfx, clang(180, 1.4) * .5, 8.6, .5); place(sfx, sparkle_sfx(), 8.62, .4)
# 2 background
place(sfx, pop(700), 10.36, .5); place(sfx, pop(800), 10.74, .35); place(sfx, pop(900), 11.24, .35)
steps(14.1, 16.6, .1, 160, .15); crackle(14.7, 17.4, .1); place(sfx, whoosh(.6), 14.6, .25)
place(sfx, thud(70, .4, 1), 16.4, .7); place(sfx, boing(260, .5), 16.42, .45)
steps(17.44, 20.9, .12, 130, .2)
place(sfx, sparkle_sfx(), 22.5, .35)
place(sfx, tweet(), 24.0, .5); place(sfx, pop(500), 25.76, .45)
place(sfx, noiseburst(.12, 800, 5000), 28.35, .6); place(sfx, boing(170, .6), 29.2, .5); place(sfx, pop(900), 29.25, .3)
place(sfx, bp(rng.standard_normal(int(.7 * SR)), 2500, 7000) * np.sin(np.pi * T(int(.7 * SR)) / .7) * .4, 29.95, .5)
for i in range(4): place(sfx, pop(450 + i * 80), 31.4 + i * .3, .45); place(sfx, thud(90, .2, .5), 31.42 + i * .3)
place(sfx, clang(220, 1.0) * .5, 33.4, .5); place(sfx, sparkle_sfx(), 33.42, .35)
# 3 the Mongols
place(sfx, waves(5.6), 34.56, .25); place(sfx, pop(600), 35.56, .4)
place(sfx, thud(45, .8, 1), 37.25, .8); place(sfx, clang(160, 1.0) * .4, 37.25, .5); steps(37.4, 40.1, .37, 70, .3)
place(sfx, thud(60, .4, 1), 41.4, .6); place(sfx, hp(rng.standard_normal(int(1.2 * SR)), 3000) * np.exp(-T(int(1.2 * SR)) * 2) * .25, 41.5, .5); place(sfx, pop(700), 43.46, .45)
place(sfx, scribble(.3), 46.37, .6); place(sfx, boing(320, .35), 47.32, .4); place(sfx, whoosh(.4), 48.9, .3); place(sfx, pop(800), 49.3, .4)
place(sfx, chime(1760, 1.0), 52.53, .5); place(sfx, sparkle_sfx(), 52.55, .4)
# 4 alliance
place(sfx, scribble(.35), 55.66, .5); place(sfx, sparkle_sfx(), 56.4, .3); place(sfx, pop(650), 58.62, .45)
place(sfx, thud(110, .2, 1), 60.7, .6); place(sfx, sparkle_sfx(), 60.75, .4)
steps(61.4, 65.2, .4, 75, .32); place(sfx, riser(1.5), 63.8, .4); steps(65.2, 66.3, .1, 150, .2)
for k in range(5): place(sfx, clang(420 + k * 60, .6) * .5, 66.4 + k * .45, .45); place(sfx, thud(80, .25, 1), 66.45 + k * .45, .4)
place(sfx, whoosh(.5, False), 68.7, .4); place(sfx, thud(55, .5, 1), 69.22, .8); place(sfx, boing(200, .6), 69.75, .45)
for k in range(5): place(sfx, clang(900 - k * 70, .4) * .5, 73.0 + k * .08, .35)
for k in range(3): place(sfx, tweet(), 70.6 + k * 1.4, .25)
# 5 twist
place(sfx, heartbeat(), 76.0, .55); place(sfx, heartbeat(), 76.8, .55); place(sfx, sparkle_sfx(), 76.8, .3)
place(sfx, pop(600), 79.2, .35)
place(sfx, whoosh(.5), 81.7, .45); place(sfx, clang(620, .9) * .6, 82.2, .55)
place(sfx, boing(380, .3), 84.18, .45); place(sfx, boing(420, .3), 84.4, .45); place(sfx, whoosh(.5), 84.0, .35)
for k in range(14): place(sfx, thud(90 + (k % 4) * 25, .12, 1), 86.4 + k * .11, .4); place(sfx, noiseburst(.05), 86.45 + k * .11, .25)
place(sfx, thud(48, .6, 1), 86.4, .7)
steps(88.0, 93.1, .09, 170, .14)
for k in range(4): place(sfx, boing(300 + k * 40, .35), 88.6 + k * 1.1, .3)
place(sfx, waves(5.0), 93.12, .25); place(sfx, pop(500), 93.92, .35)
place(sfx, thud(95, .2, 1), 96.85, .6)
# 6 ending
place(sfx, thud(45, .8, 1), 98.28, .7); place(sfx, clang(200, 1.0) * .4, 98.28, .45)
place(sfx, riser(.85), 100.8, .4); place(sfx, clang(330, 1.4) * .6, 101.63, .55); place(sfx, sparkle_sfx(), 101.65, .5)
for k in range(10): place(sfx, pop(500 + (k * 137) % 600), 101.8 + k * .13, .18)
place(sfx, sparkle_sfx(), 105.5, .35)
place(sfx, thud(60, .4, 1), 111.3, .6); place(sfx, chime(1760, 1.0), 112.88, .5); place(sfx, pop(700), 113.48, .4)
place(sfx, pop(600), 114.35, .4); place(sfx, pop(750), 114.65, .45)

# ---------------- music (procedural sea-shanty jig, D minor, 6/8) ----------------
BPM = 132  # dotted-quarter = beat; eighth = 60/BPM/... use eighth duration
E8 = 60 / BPM / 2 * 1.0  # eighth note seconds (6/8 feel)
def midi(m): return 440 * 2 ** ((m - 69) / 12)
def saw_pad(f, dur, g=.2):
    n = int(dur * SR); t = T(n); vib = 1 + .004 * np.sin(2 * np.pi * 5.5 * t)
    ph = np.cumsum(f * vib) / SR; x = 2 * (ph % 1) - 1 + .6 * (2 * ((ph * 1.005) % 1) - 1)
    x = lp(x, 1400); e = np.minimum(1, t / .06) * np.minimum(1, (dur - t) / .08)
    return x * e * g
mel = [62, 65, 69, 67, 65, 64, 62, 64, 65, 64, 62, 61, 62, 65, 69, 72, 70, 69, 67, 65, 64, 62, 61, 62]  # 24 eighths = 4 bars of 6/8
chords = [(50, 57, 62, 65), (48, 55, 60, 64), (46, 53, 58, 62), (45, 52, 57, 61)]
plk_cache = {}
def plk(m, dur):
    k = (m, round(dur, 2))
    if k not in plk_cache: plk_cache[k] = pluck(midi(m), dur)
    return plk_cache[k]
music = np.zeros(N)
def jig(t0, t1, g=1.0, mel_on=True, bass_on=True, pad_on=True, drum=True, mel_g=.55):
    t = t0; i = 0
    while t < t1:
        bar = (i // 6) % 4; ch = chords[bar]
        if bass_on and i % 6 == 0: place(music, plk(ch[0] - 12, E8 * 6) * .7, t, g)
        if pad_on and i % 6 == 0:
            for m in ch[1:]: place(music, saw_pad(midi(m), min(E8 * 6, t1 - t)), t, g * .25)
        if mel_on and i % 3 == 0: place(music, plk(mel[i % 24], E8 * 3) * .8, t, g * mel_g)
        # light percussion: frame drum on 1 and 4
        if drum and i % 6 == 0: place(music, thud(100, .12, .15), t, g)
        t += E8; i += 1
def drone(t0, t1, g=1.0):
    n = int((t1 - t0) * SR); t = T(n)
    x = (np.sin(2 * np.pi * 73.4 * t) + .5 * np.sin(2 * np.pi * 110 * t + 1) + .3 * np.sin(2 * np.pi * 146.8 * t * 1.003)) * (0.7 + .3 * np.sin(2 * np.pi * .3 * t))
    x *= np.minimum(1, t / .4) * np.minimum(1, (t1 - t0 - t) / .4)
    place(music, x * .25, t0, g)
# ---- whimsical comedic underscore (replaces jig) ----
music = np.zeros(N)
BEAT = 60 / 104
def pizz(m, dur=.45, g=1.0):
    k = ('pz', m, round(dur, 2))
    if k not in plk_cache:
        x = pluck(midi(m), dur); n = len(x); t = T(n)
        x = bp(x, 180, 3500) * np.exp(-t * 7) + bp(rng.standard_normal(n), 1500, 5000) * np.exp(-t * 300) * .15
        plk_cache[k] = x / (np.max(np.abs(x)) + 1e-9)
    return plk_cache[k] * g
def glock(m, dur=1.2, g=1.0):
    n = int(dur * SR); t = T(n); f = midi(m)
    x = (np.sin(2 * np.pi * f * t) + .35 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t * 6) + .15 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t * 12))
    return x * np.exp(-t * 3.5) * np.minimum(1, t / .002) * .5 * g
def reed(m, dur=.22, g=1.0):
    n = int(dur * SR); t = T(n); f = midi(m); ph = (f * t) % 1
    x = lp(np.sign(np.sin(2 * np.pi * ph)) * .6 + (2 * ph - 1) * .4, 900)
    return x * np.minimum(1, t / .015) * np.exp(-t * 6) * np.minimum(1, (dur - t) / .03) * .5 * g
def strings(ms, dur, g=1.0):
    n = int(dur * SR); t = T(n); x = np.zeros(n)
    for m in ms:
        for d in (-.004, 0, .005):
            ph = np.cumsum(midi(m) * (1 + d) * (1 + .003 * np.sin(2 * np.pi * 5 * t))) / SR; x += 2 * (ph % 1) - 1
    x = lp(x / (len(ms) * 3), 1100); e = np.minimum(1, t / .5) * np.minimum(1, (dur - t) / .5)
    return x * e * g
# progressions (root, chord tones) in midi
DM = [(38, (62, 65, 69)), (43, (62, 67, 71)), (38, (62, 65, 69)), (45, (61, 64, 67))]   # Dm G Dm A7
DMAJ = [(38, (62, 66, 69)), (43, (62, 67, 71)), (45, (61, 64, 69)), (38, (62, 66, 69))]  # D G A D
motif = [(0, 74), (.5, 77), (1, 81), (2, 79), (2.5, 77), (3, 76)]  # glock line over 1 bar
def playful(t0, t1, prog, g=1.0, glock_on=True, stabs=True):
    t = t0; bar = 0
    while t < t1 - .05:
        root, ch = prog[bar % 4]
        place(music, pizz(root, .5, .9), t, g); place(music, pizz(root + 7, .5, .7), t + 2 * BEAT, g)
        if stabs:
            for bt in (1, 3): 
                for m in ch: place(music, pizz(m - 12, .3, .28), t + bt * BEAT, g)
        if glock_on and bar % 2 == 0:
            for (bt, m) in motif:
                mm = m if prog is DM else m + (1 if m % 12 in (5,) else 0)
                if t + bt * BEAT < t1: place(music, glock(mm, 1.0, .35), t + bt * BEAT, g)
        t += 4 * BEAT; bar += 1
def sneak(t0, t1, g=1.0):
    steps = [38, 38, 41, 40, 39, 38, 36, 37]
    t = t0; i = 0
    while t < t1 - .05:
        place(music, reed(steps[i % 8] + 12, .2, .8), t, g); place(music, pizz(steps[i % 8], .35, .6), t, g)
        t += BEAT * (1 if i % 2 == 0 else 1); i += 1
def drums(t0, t1, g=1.0):
    t = t0; i = 0
    while t < t1 - .05:
        place(music, thud(85, .2, .9), t, g)
        if i % 2: place(music, noiseburst(.04, 3000, 9000) * .6, t + BEAT * .5, g)
        t += BEAT * .5; i += 1
place(music, strings((50, 57, 62), 3.4, .45), 0); drone(0, 3.4, .8)
drums(3.3, 5.8, .9); place(music, strings((50, 56, 62), 2.6, .4), 3.3)
playful(5.8, 7.3, DM, .7, glock_on=False)
place(music, strings((50, 57, 62, 66), 3.0, .5), 7.3)
for (bt, m) in motif: place(music, glock(m, 1.0, .3), 8.6 + bt * BEAT * .5)
playful(10.24, 29.84, DM, .7)
sneak(29.84, 33.3, .8); playful(33.3, 34.56, DMAJ, .8)
place(music, strings((50, 57, 62), 19.2, .3), 34.56); playful(34.56, 51.3, DM, .5, glock_on=False)
sneak(51.3, 53.7, .7)
playful(53.76, 66.32, DMAJ, .75)
drums(66.32, 70.32, 1.0); place(music, strings((50, 56, 62), 4.0, .4), 66.32)
playful(70.32, 75.6, DMAJ, .85)
sneak(75.6, 83.28, .9); place(music, strings((50, 56, 62), 7.7, .3), 75.6)
drums(83.28, 93.12, .9); place(music, strings((50, 57, 62), 9.8, .35), 83.28)
place(music, strings((50, 57, 62, 65), 5.0, .4), 93.12)
for k, m in enumerate([81, 77, 74, 69, 65, 62]): place(music, glock(m, 1.0, .25), 93.4 + k * .6)
playful(98.08, 116.2, DMAJ, .85)
for k, m in enumerate([62, 66, 69, 74, 78, 81, 86]): place(music, glock(m, .9, .28), 104.3 + k * .5)
place(music, strings((50, 57, 62, 66), 3.0, .5), 113.9)
for m in (62, 66, 69, 74): place(music, pizz(m - 12, .8, .5), 116.0); place(music, glock(m + 12, 1.3, .25), 116.0)
music = lp(music, 6000)

# ---------------- VO + mix ----------------
vo, vsr = sf.read('audio/vo.wav')
if vo.ndim > 1: vo = vo.mean(1)
vo = signal.resample_poly(vo, SR, vsr)
vo = hp(vo, 90)
# gentle compression
envv = np.abs(signal.hilbert(vo)); envv = lp(envv, 20)
gain = np.where(envv > .15, (.15 / np.maximum(envv, 1e-6)) ** .4, 1.0); vo = vo * gain
vo = vo / np.max(np.abs(vo)) * .9
VO = np.zeros(N); VO[:min(N, len(vo))] = vo[:N]
# duck music under VO
venv = lp(np.abs(VO), 6); vtrack = np.clip(venv / .05, 0, 1)
duck = 1 - .55 * vtrack
mixL = VO * 1.0 + music * .22 * duck + sfx * .7
mixR = mixL.copy()
out = np.stack([mixL, mixR], 1)
fade = np.ones(N); fl = int(.5 * SR); fade[-fl:] = np.linspace(1, 0, fl); out *= fade[:, None]
pk = np.max(np.abs(out)); out = out / pk * .89
sf.write('audio/mix.wav', out, SR)
print('done', out.shape, 'rms dB', 20 * np.log10(np.sqrt(np.mean(out ** 2))))
